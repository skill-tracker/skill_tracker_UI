import { Component, OnInit, Input } from '@angular/core';
import { Skill } from '../skill';
import { SkillService } from 'src/app/skill.service';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-skill-edit',
  templateUrl: './skill-edit.component.html',
  styleUrls: ['./skill-edit.component.css']
})
export class SkillEditComponent implements OnInit {

  @Input()
  skill:Skill;
    constructor(private route:ActivatedRoute,private service:SkillService) { }
  

  ngOnInit() {
    // let skill_id=+this.route.snapshot.paramMap.get("skill_id");
    //   console.log("update"+skill_id);
    // this.service.getSkillById(skill_id).subscribe(p=> this.skill=p[0]);
    //  console.log("pizza="+this.pizza);
  }

  

  updateSkill(skill_id:any,priority:any){
    this.service.updateSkill(skill_id,priority);

  }

}
