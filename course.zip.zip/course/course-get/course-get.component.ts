import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-course-get',
  templateUrl: './course-get.component.html',
  styleUrls: ['./course-get.component.css']
})
export class CourseGetComponent implements OnInit {

  board:Object;
  errorMessage: string;


  constructor(private userService : UserService) { }

  ngOnInit() {
    this.userService.getCourseBoard().subscribe(
      data => {
        this.board = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }



    );
}
}
