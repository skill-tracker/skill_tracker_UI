import { Component, OnInit } from '@angular/core';

import { Job } from '../job';
import { UserService } from 'src/app/services/user.service';


@Component({
  selector: 'app-job-get',
  templateUrl: './job-get.component.html',
  styleUrls: ['./job-get.component.css']
})
export class JobGetComponent implements OnInit {
  board: Object;
  errorMessage: string;
  job:Job;
  selectedJob:Job;
 
  constructor(private userService: UserService) { }
  ngOnInit() {
    this.userService.getJobBoard().subscribe(
      data => {
        this.board = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }     
    );
}
onSelection(job:Job){
  this.selectedJob=job;
}
deleteJob(job_id: any) {
  this.userService.deleteJob(job_id)
    .subscribe(
      data => {
        console.log(data);
      
      },
      error => console.log(error));
}



}
