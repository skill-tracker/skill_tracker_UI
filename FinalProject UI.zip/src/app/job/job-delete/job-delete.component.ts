import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Job } from '../job';
import { JobGetComponent } from '../job-get/job-get.component';

@Component({
  selector: 'app-job-delete',
  templateUrl: './job-delete.component.html',
  styleUrls: ['./job-delete.component.css']
})
export class JobDeleteComponent implements OnInit {

  constructor(private service:UserService,private listComponent:JobGetComponent) { }

  ngOnInit() {
  }
}
