import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  // private userUrl = 'http://localhost:8080/api/jobs/admin/all';
  private  userUrl='http://localhost:8080/api/test/user';
  private pmUrl = 'http://localhost:8080/api/test/pm';
  private adminUrl = 'http://localhost:8080/api/test/admin';
  private jobUrl = 'http://localhost:8080/api/test/jobs';
  private courseUrl = 'http://localhost:8080/api/test/courses';
  private skillUrl = 'http://localhost:8080/api/test/skills';


 //private deleteUrl='http://localhost:8080/api/jobs/admin/delete/:job_id';

  constructor(private http: HttpClient) { }

  getUserBoard(): Observable<Object> {
    return this.http.get(this.userUrl, { responseType: 'json' });
  }

  getPMBoard(): Observable<string> {
    return this.http.get(this.pmUrl, { responseType: 'text' });
  }

  getAdminBoard(): Observable<string> {
    return this.http.get(this.adminUrl, { responseType: 'text' });
  }
  getJobBoard(): Observable<Object> {
    return this.http.get(this.jobUrl,{responseType: 'json'});
  }
 
  addJobBoard(job:Object): Observable<Object> {
    return this.http.post(`${this.jobUrl}`+'/create', job);
  }
  
  getCourseBoard(): Observable<Object> {
    return this.http.get(this.courseUrl,{responseType: 'json'});
  }
  addCourseBoard(course:Object): Observable<Object> {
    return this.http.post(`${this.courseUrl}`+'/create', course);
  }
 
  getSkillBoard(): Observable<Object> {
    return this.http.get(this.skillUrl,{responseType: 'json'});
  }
  addSkillBoard(job:Object): Observable<Object> {
    return this.http.post(`${this.skillUrl}`+'/create', job);
  }
  deleteJob(job_id: any): Observable<Object> {
    console.log(`${this.jobUrl}/delete/${job_id}`);
    return this.http.delete(`${this.jobUrl}/delete/${job_id}`);
    
  }
  deleteCourse(course_id: any): Observable<Object> {
    console.log(`${this.courseUrl}/delete/${course_id}`);
    return this.http.delete(`${this.courseUrl}/delete/${course_id}`);
    
  }
  deleteSkill(skill_id: any): Observable<Object> {
    console.log(`${this.skillUrl}/delete/${skill_id}`);
    return this.http.delete(`${this.skillUrl}/delete/${skill_id}`);
    
  }
  updateSkill(id:number,value:any):Observable<Object>
  {
    console.log("in service edit");
    return this.http.put(`${this.skillUrl}/update/${id}`,value);
  }

  getJobBoard1(): Observable<Object> {
    return this.http.get(this.jobUrl,{responseType: 'json'});
  }
  getCourseBoard1(): Observable<Object> {
    return this.http.get(this.courseUrl,{responseType: 'json'});
  }
  getSkillBoard1(): Observable<Object> {
    return this.http.get(this.skillUrl,{responseType: 'json'});
  }

  
}
