import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './user/user.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { PmComponent } from './pm/pm.component';
import { httpInterceptorProviders } from './auth/auth-interceptor';
import { JobGetComponent } from './job/job-get/job-get.component';
import { JobAddComponent } from './job/job-add/job-add.component';
import { CourseGetComponent } from './course/course-get/course-get.component';
import { JobDeleteComponent } from './job/job-delete/job-delete.component';
import { SkillAddComponent } from './skill/skill-add/skill-add.component';
import { SkillGetComponent } from './skill/skill-get/skill-get.component';
import { CourseAddComponent } from './course/course-add/course-add.component';
import { SkillEditComponent } from './skill/skill-edit/skill-edit.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    UserComponent,
    RegisterComponent,
    HomeComponent,
    AdminComponent,
    PmComponent,
    JobGetComponent,
    JobAddComponent,
    JobDeleteComponent,
    CourseGetComponent,
    CourseAddComponent,
    SkillGetComponent,
    SkillAddComponent,
    SkillEditComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    
    
    

   
  ],
  providers: [httpInterceptorProviders],
  bootstrap: [AppComponent]
})
export class AppModule { }
