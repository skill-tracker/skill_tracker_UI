import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { UserComponent } from './user/user.component';
import { PmComponent } from './pm/pm.component';
import { AdminComponent } from './admin/admin.component';
import { JobGetComponent } from './job/job-get/job-get.component';
import { JobAddComponent } from './job/job-add/job-add.component';
import { CourseGetComponent } from './course/course-get/course-get.component';
import { SkillGetComponent } from './skill/skill-get/skill-get.component';
import { SkillAddComponent } from './skill/skill-add/skill-add.component';
import { CourseAddComponent } from './course/course-add/course-add.component';
import { SkillEditComponent } from './skill/skill-edit/skill-edit.component';


const routes: Routes = [
    {
        path: 'home',
        component: HomeComponent
    },
    {
        path: 'user',
        component: UserComponent
    },
    {
        path: 'pm',
        component: PmComponent
    },
    {
        path: 'admin',
        component: AdminComponent
    },
    {
        path: 'auth/login',
        component: LoginComponent
    },
    {
        path: 'signup',
        component: RegisterComponent
    },
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    {
        path:'jobs',
        component:JobGetComponent
    },
    {
        path:'courses',
        component:CourseGetComponent
    },
    {
        path:'courses/create',
        component:CourseAddComponent
    },
    {
        path:'jobs/create',
        component:JobAddComponent
    },

    {
        path:'skills',
        component:SkillGetComponent
    },
    {
        path:'skills/create',
        component:SkillAddComponent
    },
    {
        path:'skills/update',
        component:SkillEditComponent
    },

    {
        path:'jobs/delete/:job_id',
        component:JobGetComponent
    }
    
   
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
