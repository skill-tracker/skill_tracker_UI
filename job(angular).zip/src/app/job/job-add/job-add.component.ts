import { Component, OnInit } from '@angular/core';
import { JobService } from 'src/app/job.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-job-add',
  templateUrl: './job-add.component.html',
  styleUrls: ['./job-add.component.css']
})
export class JobAddComponent implements OnInit {
  angForm:FormGroup;
  constructor(private fb: FormBuilder , private jobService:JobService) { this.createForm();}

  ngOnInit() {
  }
  createForm(){
    this.angForm=this.fb.group({
      job_id:['',Validators.required],
      company_name:['',Validators.required],
      job_desc:['',Validators.required],
      job_title:['',Validators.required],
      job_url:['',Validators.required],
    });
  }
  addJob(job_id,company_name,job_desc,job_title,job_url):void{
    this.jobService.addJob(job_id,company_name,job_desc,job_title,job_url);
  }
}
