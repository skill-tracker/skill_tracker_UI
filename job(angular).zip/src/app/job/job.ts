export class Job {
    _id?:number;
    job_d: number;
    company_name:string;
    job_desc:string;
    job_title:string;
    job_url:string;
    _v?:number;
}
