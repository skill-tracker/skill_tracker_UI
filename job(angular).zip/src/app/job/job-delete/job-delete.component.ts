import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { JobService } from 'src/app/job.service';

@Component({
  selector: 'app-job-delete',
  templateUrl: './job-delete.component.html',
  styleUrls: ['./job-delete.component.css']
})
export class JobDeleteComponent implements OnInit {
  
  constructor(private route:ActivatedRoute,private jobService:JobService) { }

  ngOnInit() {
    let job_id=this.route.snapshot.paramMap.get("job_id");
   this.deleteJob(job_id);
  }
  deleteJob(job_id){
    this.jobService.deleteJob(job_id);
}
}
