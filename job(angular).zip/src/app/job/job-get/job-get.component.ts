import { Component, OnInit } from '@angular/core';
import { Job } from '../job';
import { ActivatedRoute } from '@angular/router';
import { JobService } from 'src/app/job.service';

@Component({
  selector: 'app-job-get',
  templateUrl: './job-get.component.html',
  styleUrls: ['./job-get.component.css']
})
export class JobGetComponent implements OnInit {
  jobs:Job[]=[];
  selectedJob: Job;
  constructor(private route:ActivatedRoute, private service:JobService) { }

  ngOnInit() {
    this.service.getJobs().subscribe(jobList=>this.jobs=jobList);
  }

  onSelection(job:Job){
    this.selectedJob=job;
  }

}
