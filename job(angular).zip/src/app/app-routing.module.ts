import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { JobGetComponent } from './job/job-get/job-get.component';
import { JobAddComponent } from './job/job-add/job-add.component';
import { JobDeleteComponent } from './job/job-delete/job-delete.component';

const routes: Routes = [
  {path:'',redirectTo:'/job',pathMatch:'full'},
  {path:'job',component:JobGetComponent},
  {path:'',redirectTo:'/save',pathMatch:'full'},
  {path:'save',component:JobAddComponent},
  {path:'',redirectTo:'/jobs/delete/:job_id',pathMatch:'full'},
  {path:'jobs/delete/:job_id',component:JobDeleteComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
