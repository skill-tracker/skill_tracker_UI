import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Job } from './job/job';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class JobService {
  uri='http://localhost:8080/job'; 
  constructor(public httpClient:HttpClient) { }

  getJobs():Observable<Job[]>{
    return this.httpClient.get<Job[]>(`${this.uri}`+'/jobs'); 
   }

   addJob(job_id,company_name,job_desc,job_title,job_url){
    let job={
      job_id:job_id,
      company_name:company_name,
      job_desc:job_desc,
      job_title:job_title,
      job_url:job_url
    }
    return this.httpClient.post(`${this.uri}`+'/jobs/save',job)
    .subscribe(res=>console.log("New Job added"));
  }

  deleteJob(job_id: number):any {
    this.httpClient.delete(`${this.uri}`+'/jobs/delete/'+`${job_id}`)
    .subscribe(res=>console.log("job deleted"));
  }
}
