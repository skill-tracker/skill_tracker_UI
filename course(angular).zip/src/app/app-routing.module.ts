import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CourseGetComponent } from './course/course-get/course-get.component';
import { CourseDeleteComponent } from './course/course-delete/course-delete.component';
import { CourseAddComponent } from './course/course-add/course-add.component';


const routes: Routes = [{path:'',redirectTo:'/course',pathMatch:'full'},
{path:'course',component:CourseGetComponent},
{path:'',redirectTo:'/save',pathMatch:'full'},
 {path:'save',component:CourseAddComponent},
{path:'',redirectTo:'/courses/delete/:course_id',pathMatch:'full'},
{path:'courses/delete/:course_id',component:CourseDeleteComponent},];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
