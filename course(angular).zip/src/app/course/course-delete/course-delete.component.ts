import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-course-delete',
  templateUrl: './course-delete.component.html',
  styleUrls: ['./course-delete.component.css']
})
export class CourseDeleteComponent implements OnInit {

  constructor(private route:ActivatedRoute,private courseService:CourseService) { }

  ngOnInit() {
    let course_id=this.route.snapshot.paramMap.get("course_id");
   this.deleteCourse(course_id);
  }
  deleteCourse(course_id){
    this.courseService.deleteCourse(course_id);
}
}
