import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';
import { Course } from '../course';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-course-get',
  templateUrl: './course-get.component.html',
  styleUrls: ['./course-get.component.css']
})
export class CourseGetComponent implements OnInit {
  courses:Course[]=[];
  selectedUser:Course;
  constructor(private route:ActivatedRoute,
    private service:CourseService){ }

  ngOnInit() {
    this.service.getCourses()
    .subscribe(courseList=>this.courses=courseList);
  }
  onSelection(course:Course){
    this.selectedUser=course;
  }
}
