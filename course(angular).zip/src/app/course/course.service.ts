import { Injectable } from '@angular/core';
import { Course } from './course';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CourseService { 
  
  

  uri="http://localhost:8080/course";

  constructor(public httpClient:HttpClient) { }

  
  getCourses():Observable<Course[]>{
    return this.httpClient.get<Course[]>(`${this.uri}`+'/courses');
  }
  
  addCourse(course_id,course_name,description,link){
    let course={
      course_id:course_id,
      course_name:course_name,
      description:description,
      link:link
    }
    return this.httpClient.post(`${this.uri}`+'/courses/save',course)
    .subscribe(res=>console.log("New Course added"));
  }


  deleteCourse(course_id: number):any {
    this.httpClient.delete(`${this.uri}`+'/courses/delete/'+`${course_id}`)
    .subscribe(res=>console.log("course deleted"));
  }

 


}
