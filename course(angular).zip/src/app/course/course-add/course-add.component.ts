import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-course-add',
  templateUrl: './course-add.component.html',
  styleUrls: ['./course-add.component.css']
})
export class CourseAddComponent implements OnInit {
  angForm:FormGroup;
  constructor(private fb: FormBuilder , private courseService:CourseService) { this.createForm();}

  ngOnInit() {
  }
  createForm(){
    this.angForm=this.fb.group({
      course_id :['',Validators.required],
      course_name:['',Validators.required],
      description:['',Validators.required],
      link:['',Validators.required],
      
    });
  }
  addCourse(course_id,course_name,description,link):void{
    this.courseService.addCourse(course_id,course_name,description,link);
  }
}
