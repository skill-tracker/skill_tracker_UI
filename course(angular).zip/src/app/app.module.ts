import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { CourseComponent } from './course/course.component';
import { HttpClientModule } from '@angular/common/http';

import { CourseGetComponent } from './course/course-get/course-get.component';
import { CourseDeleteComponent } from './course/course-delete/course-delete.component';
import { CourseAddComponent } from './course/course-add/course-add.component';



@NgModule({
  declarations: [
    AppComponent,
    CourseComponent,
    CourseGetComponent,
    CourseDeleteComponent,
    CourseAddComponent
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
