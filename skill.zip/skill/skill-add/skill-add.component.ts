import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { Skill } from '../skill';

@Component({
  selector: 'app-skill-add',
  templateUrl: './skill-add.component.html',
  styleUrls: ['./skill-add.component.css']
})
export class SkillAddComponent implements OnInit {
  submitted=false;
  angForm:FormGroup;
  skill:Skill=new Skill();
  constructor(private fb:FormBuilder,private userService: UserService) { 
    this.createForm();
  }
  ngOnInit() {
  }
  createForm(){
    this.angForm=this.fb.group({
      skill_id:['',Validators.required], // if it is blank and validator says it is req, then it gives err
      skill_name:['',Validators.required],
      priority:['',Validators.required],
   });
  
 }
 newSkill():void{
   this.submitted=false;
   this.skill=new Skill();
 }
 save(){
   this.userService.addSkillBoard(this.skill)
   .subscribe(data=>console.log(data),error=>console.log(error));
   this.skill=new Skill();
 }
 onSubmit(){
  this.submitted=true;
  this.save();
 }

}
